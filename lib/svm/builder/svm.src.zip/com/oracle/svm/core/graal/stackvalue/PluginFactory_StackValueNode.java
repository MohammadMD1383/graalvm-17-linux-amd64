// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.graal.stackvalue;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.nodes.graphbuilderconf.JacocoIgnoreGenerated;

//        class: com.oracle.svm.core.graal.stackvalue.StackValueNode
//       method: stackValue(int,int,com.oracle.svm.core.graal.stackvalue.StackValueNode.StackSlotIdentity)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_StackValueNode_stackValue extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        int arg0;
        if (args[0].isConstant()) {
            arg0 = args[0].asJavaConstant().asInt();
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_StackValueNode_stackValue.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        int arg1;
        if (args[1].isConstant()) {
            arg1 = args[1].asJavaConstant().asInt();
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_StackValueNode_stackValue.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[1];
            return false;
        }
        com.oracle.svm.core.graal.stackvalue.StackValueNode.StackSlotIdentity arg2;
        if (args[2].isConstant()) {
            arg2 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.graal.stackvalue.StackValueNode.StackSlotIdentity.class, args[2].asJavaConstant());
            assert arg2 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_StackValueNode_stackValue.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[2];
            return false;
        }
        com.oracle.svm.core.graal.stackvalue.StackValueNode node = new com.oracle.svm.core.graal.stackvalue.StackValueNode(arg0, arg1, arg2);
        b.addPush(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_StackValueNode_stackValue(GeneratedPluginInjectionProvider injection) {
        super("stackValue", int.class, int.class, com.oracle.svm.core.graal.stackvalue.StackValueNode.StackSlotIdentity.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.graal.stackvalue.StackValueNode
//       method: stackValue(int,int,com.oracle.svm.core.graal.stackvalue.StackValueNode.StackSlotIdentity)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_StackValueNode_stackValue implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_StackValueNode_stackValue();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        int arg0;
        if (args.get(0).isConstant()) {
            arg0 = args.get(0).asJavaConstant().asInt();
        } else {
            return false;
        }
        int arg1;
        if (args.get(1).isConstant()) {
            arg1 = args.get(1).asJavaConstant().asInt();
        } else {
            return false;
        }
        com.oracle.svm.core.graal.stackvalue.StackValueNode.StackSlotIdentity arg2;
        if (args.get(2).isConstant()) {
            arg2 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.graal.stackvalue.StackValueNode.StackSlotIdentity.class, args.get(2).asJavaConstant());
            assert arg2 != null;
        } else {
            return false;
        }
        com.oracle.svm.core.graal.stackvalue.StackValueNode node = new com.oracle.svm.core.graal.stackvalue.StackValueNode(arg0, arg1, arg2);
        b.addPush(JavaKind.Object, node);
        return true;
    }
}

public class PluginFactory_StackValueNode implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.graal.stackvalue.StackValueNode.class, new Plugin_StackValueNode_stackValue(injection));
    }
}
