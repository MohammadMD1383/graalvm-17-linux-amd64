// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.graal.nodes;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.nodes.graphbuilderconf.JacocoIgnoreGenerated;

//        class: com.oracle.svm.core.graal.nodes.NewPodInstanceNode
//       method: newPodInstance(java.lang.Class<?>,java.lang.Class<?>,int,byte[])
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_NewPodInstanceNode_newPodInstance extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        jdk.vm.ci.meta.ResolvedJavaType arg0;
        if (args[0].isConstant()) {
            jdk.vm.ci.meta.JavaConstant cst = args[0].asJavaConstant();
            arg0 = b.getConstantReflection()/* A CONSTANT_REFLECTION */.asJavaType(cst);
            if (arg0 == null) {
                arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(jdk.vm.ci.meta.ResolvedJavaType.class, cst);
            }
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_NewPodInstanceNode_newPodInstance.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        ValueNode arg1 = args[1];
        ValueNode arg2 = args[2];
        ValueNode arg3 = args[3];
        com.oracle.svm.core.graal.nodes.NewPodInstanceNode node = new com.oracle.svm.core.graal.nodes.NewPodInstanceNode(arg0, arg1, arg2, arg3);
        b.addPush(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_NewPodInstanceNode_newPodInstance(GeneratedPluginInjectionProvider injection) {
        super("newPodInstance", java.lang.Class.class, java.lang.Class.class, int.class, byte[].class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.graal.nodes.NewPodInstanceNode
//       method: newPodInstance(java.lang.Class<?>,java.lang.Class<?>,int,byte[])
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_NewPodInstanceNode_newPodInstance implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_NewPodInstanceNode_newPodInstance();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        jdk.vm.ci.meta.ResolvedJavaType arg0;
        if (args.get(0).isConstant()) {
            jdk.vm.ci.meta.JavaConstant cst = args.get(0).asJavaConstant();
            arg0 = b.getConstantReflection()/* B CONSTANT_REFLECTION */.asJavaType(cst);
            if (arg0 == null) {
                arg0 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(jdk.vm.ci.meta.ResolvedJavaType.class, cst);
            }
        } else {
            return false;
        }
        ValueNode arg1 = args.get(1);
        ValueNode arg2 = args.get(2);
        ValueNode arg3 = args.get(3);
        com.oracle.svm.core.graal.nodes.NewPodInstanceNode node = new com.oracle.svm.core.graal.nodes.NewPodInstanceNode(arg0, arg1, arg2, arg3);
        b.addPush(JavaKind.Object, node);
        return true;
    }
}

public class PluginFactory_NewPodInstanceNode implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.graal.nodes.NewPodInstanceNode.class, new Plugin_NewPodInstanceNode_newPodInstance(injection));
    }
}
