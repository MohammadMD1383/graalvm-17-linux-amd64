// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.cpufeature;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.ConstantNode;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.nodes.graphbuilderconf.JacocoIgnoreGenerated;

//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl
//       method: <T>computeFeatureMask(java.util.EnumSet<T>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_RuntimeCPUFeatureCheckImpl_computeFeatureMask extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheckImpl_computeFeatureMask.FUNCTION);
            return true;
        }
        com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl arg0;
        if (args[0].isConstant()) {
            arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.class, args[0].asJavaConstant());
            assert arg0 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheckImpl_computeFeatureMask.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.util.EnumSet arg1;
        if (args[1].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.util.EnumSet.class, args[1].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheckImpl_computeFeatureMask.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[1];
            return false;
        }
        @SuppressWarnings({"unchecked"})
        int result = arg0.computeFeatureMask(arg1);
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_RuntimeCPUFeatureCheckImpl_computeFeatureMask(GeneratedPluginInjectionProvider injection) {
        super("computeFeatureMask", InvocationPlugin.Receiver.class, java.util.EnumSet.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl
//       method: <T>computeFeatureMask(java.util.EnumSet<T>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_RuntimeCPUFeatureCheckImpl_computeFeatureMask implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_RuntimeCPUFeatureCheckImpl_computeFeatureMask();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl arg0;
        if (args.get(0).isConstant()) {
            arg0 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.class, args.get(0).asJavaConstant());
            assert arg0 != null;
        } else {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.util.EnumSet arg1;
        if (args.get(1).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.util.EnumSet.class, args.get(1).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        @SuppressWarnings({"unchecked"})
        int result = arg0.computeFeatureMask(arg1);
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl
//       method: getStaticFeatures()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_RuntimeCPUFeatureCheckImpl_getStaticFeatures extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheckImpl_getStaticFeatures.FUNCTION);
            return true;
        }
        @SuppressWarnings({"rawtypes"})
        java.util.EnumSet result = com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.getStaticFeatures();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_RuntimeCPUFeatureCheckImpl_getStaticFeatures(GeneratedPluginInjectionProvider injection) {
        super("getStaticFeatures");
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl
//       method: getStaticFeatures()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_RuntimeCPUFeatureCheckImpl_getStaticFeatures implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_RuntimeCPUFeatureCheckImpl_getStaticFeatures();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        @SuppressWarnings({"rawtypes"})
        java.util.EnumSet result = com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.getStaticFeatures();
        JavaConstant constant = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl
//       method: removeStaticFeatures(java.util.EnumSet<?>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_RuntimeCPUFeatureCheckImpl_removeStaticFeatures extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheckImpl_removeStaticFeatures.FUNCTION);
            return true;
        }
        @SuppressWarnings({"rawtypes"})
        java.util.EnumSet arg0;
        if (args[0].isConstant()) {
            arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.util.EnumSet.class, args[0].asJavaConstant());
            assert arg0 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheckImpl_removeStaticFeatures.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.util.EnumSet result = com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.removeStaticFeatures(arg0);
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_RuntimeCPUFeatureCheckImpl_removeStaticFeatures(GeneratedPluginInjectionProvider injection) {
        super("removeStaticFeatures", java.util.EnumSet.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl
//       method: removeStaticFeatures(java.util.EnumSet<?>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_RuntimeCPUFeatureCheckImpl_removeStaticFeatures implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_RuntimeCPUFeatureCheckImpl_removeStaticFeatures();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        @SuppressWarnings({"rawtypes"})
        java.util.EnumSet arg0;
        if (args.get(0).isConstant()) {
            arg0 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.util.EnumSet.class, args.get(0).asJavaConstant());
            assert arg0 != null;
        } else {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.util.EnumSet result = com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.removeStaticFeatures(arg0);
        JavaConstant constant = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl
//       method: shouldCreateRuntimeFeatureCheck(java.util.EnumSet<?>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_RuntimeCPUFeatureCheckImpl_shouldCreateRuntimeFeatureCheck extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheckImpl_shouldCreateRuntimeFeatureCheck.FUNCTION);
            return true;
        }
        @SuppressWarnings({"rawtypes"})
        java.util.EnumSet arg0;
        if (args[0].isConstant()) {
            arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.util.EnumSet.class, args[0].asJavaConstant());
            assert arg0 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheckImpl_shouldCreateRuntimeFeatureCheck.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        boolean result = com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.shouldCreateRuntimeFeatureCheck(arg0);
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_RuntimeCPUFeatureCheckImpl_shouldCreateRuntimeFeatureCheck(GeneratedPluginInjectionProvider injection) {
        super("shouldCreateRuntimeFeatureCheck", java.util.EnumSet.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl
//       method: shouldCreateRuntimeFeatureCheck(java.util.EnumSet<?>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_RuntimeCPUFeatureCheckImpl_shouldCreateRuntimeFeatureCheck implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_RuntimeCPUFeatureCheckImpl_shouldCreateRuntimeFeatureCheck();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        @SuppressWarnings({"rawtypes"})
        java.util.EnumSet arg0;
        if (args.get(0).isConstant()) {
            arg0 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.util.EnumSet.class, args.get(0).asJavaConstant());
            assert arg0 != null;
        } else {
            return false;
        }
        boolean result = com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.shouldCreateRuntimeFeatureCheck(arg0);
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

public class PluginFactory_RuntimeCPUFeatureCheckImpl implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.class, new Plugin_RuntimeCPUFeatureCheckImpl_computeFeatureMask(injection));
        plugins.register(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.class, new Plugin_RuntimeCPUFeatureCheckImpl_getStaticFeatures(injection));
        plugins.register(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.class, new Plugin_RuntimeCPUFeatureCheckImpl_removeStaticFeatures(injection));
        plugins.register(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.class, new Plugin_RuntimeCPUFeatureCheckImpl_shouldCreateRuntimeFeatureCheck(injection));
    }
}
