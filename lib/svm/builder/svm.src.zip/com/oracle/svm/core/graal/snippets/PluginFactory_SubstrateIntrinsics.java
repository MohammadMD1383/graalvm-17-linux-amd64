// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.graal.snippets;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.debug.GraalError;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.nodes.graphbuilderconf.JacocoIgnoreGenerated;

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: breakpoint()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_SubstrateIntrinsics_breakpoint extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.nodes.BreakpointNode node = new org.graalvm.compiler.nodes.BreakpointNode();
        b.add(node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_SubstrateIntrinsics_breakpoint() {
        super("breakpoint");
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: loadHub(java.lang.Object)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_SubstrateIntrinsics_loadHub extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.nodes.spi.StampProvider arg0 = b.getStampProvider();
        ValueNode arg1 = args[0];
        org.graalvm.compiler.nodes.extended.LoadHubNode node = new org.graalvm.compiler.nodes.extended.LoadHubNode(arg0, arg1);
        b.addPush(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_SubstrateIntrinsics_loadHub() {
        super("loadHub", java.lang.Object.class);
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: loadHubOrNull(java.lang.Object)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_SubstrateIntrinsics_loadHubOrNull extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.nodes.spi.StampProvider arg0 = b.getStampProvider();
        ValueNode arg1 = args[0];
        org.graalvm.compiler.nodes.extended.LoadHubOrNullNode node = new org.graalvm.compiler.nodes.extended.LoadHubOrNullNode(arg0, arg1);
        b.addPush(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_SubstrateIntrinsics_loadHubOrNull() {
        super("loadHubOrNull", java.lang.Object.class);
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateIntrinsics_runtimeCall__0 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__0.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__0.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateIntrinsics_runtimeCall__0(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(void.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateIntrinsics_runtimeCall__0 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateIntrinsics_runtimeCall__0();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(void.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,long,jdk.vm.ci.meta.SpeculationLog.SpeculationReason)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateIntrinsics_runtimeCall__1 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__1.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        ValueNode arg3 = args[2];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__1.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateIntrinsics_runtimeCall__1(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, long.class, jdk.vm.ci.meta.SpeculationLog.SpeculationReason.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(void.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,long,jdk.vm.ci.meta.SpeculationLog.SpeculationReason)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateIntrinsics_runtimeCall__1 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateIntrinsics_runtimeCall__1();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(void.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        ValueNode arg3 = args.get(2);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Object)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateIntrinsics_runtimeCall__2 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__2.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__2.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateIntrinsics_runtimeCall__2(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, java.lang.Object.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(java.lang.Object.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Object)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateIntrinsics_runtimeCall__2 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateIntrinsics_runtimeCall__2();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(java.lang.Object.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,byte[])
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateIntrinsics_runtimeCall__3 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__3.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__3.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateIntrinsics_runtimeCall__3(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, byte[].class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(void.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,byte[])
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateIntrinsics_runtimeCall__3 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateIntrinsics_runtimeCall__3();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(void.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,byte[],java.lang.Object)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateIntrinsics_runtimeCall__4 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__4.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        ValueNode arg3 = args[2];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__4.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateIntrinsics_runtimeCall__4(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, byte[].class, java.lang.Object.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(void.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,byte[],java.lang.Object)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateIntrinsics_runtimeCall__4 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateIntrinsics_runtimeCall__4();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(void.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        ValueNode arg3 = args.get(2);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Throwable,org.graalvm.word.Pointer)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateIntrinsics_runtimeCall__5 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__5.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        ValueNode arg3 = args[2];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__5.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateIntrinsics_runtimeCall__5(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, java.lang.Throwable.class, org.graalvm.word.Pointer.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(void.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Throwable,org.graalvm.word.Pointer)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateIntrinsics_runtimeCall__5 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateIntrinsics_runtimeCall__5();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(void.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        ValueNode arg3 = args.get(2);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Throwable)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateIntrinsics_runtimeCall__6 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__6.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__6.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateIntrinsics_runtimeCall__6(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, java.lang.Throwable.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(void.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Throwable)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateIntrinsics_runtimeCall__6 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateIntrinsics_runtimeCall__6();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(void.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.word.Pointer)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateIntrinsics_runtimeCall__7 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__7.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__7.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateIntrinsics_runtimeCall__7(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, org.graalvm.word.Pointer.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(org.graalvm.word.Pointer.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.word.Pointer)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateIntrinsics_runtimeCall__7 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateIntrinsics_runtimeCall__7();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(org.graalvm.word.Pointer.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.String)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateIntrinsics_runtimeCall__8 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__8.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateIntrinsics_runtimeCall__8.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateIntrinsics_runtimeCall__8(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, java.lang.String.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(java.lang.Object.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateIntrinsics
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.String)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateIntrinsics_runtimeCall__8 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateIntrinsics_runtimeCall__8();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(java.lang.Object.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

public class PluginFactory_SubstrateIntrinsics implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_breakpoint());
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_loadHub());
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_loadHubOrNull());
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_runtimeCall__0(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_runtimeCall__1(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_runtimeCall__2(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_runtimeCall__3(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_runtimeCall__4(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_runtimeCall__5(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_runtimeCall__6(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_runtimeCall__7(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateIntrinsics.class, new Plugin_SubstrateIntrinsics_runtimeCall__8(injection));
    }
}
