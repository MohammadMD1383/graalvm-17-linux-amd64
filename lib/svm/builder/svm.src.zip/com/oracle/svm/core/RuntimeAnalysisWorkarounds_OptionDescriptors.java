// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: RuntimeAnalysisWorkarounds.java
package com.oracle.svm.core;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class RuntimeAnalysisWorkarounds_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "ConstantFoldSamplingCodeStartId": {
            return OptionDescriptor.create(
                /*name*/ "ConstantFoldSamplingCodeStartId",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Use the option to avoid the initial value of the enterSamplingCodeMethodId constant folding. The value of this option must never be set to true in order to keep the correct information in the variable.",
                /*declaringClass*/ RuntimeAnalysisWorkarounds.Options.class,
                /*fieldName*/ "ConstantFoldSamplingCodeStartId",
                /*option*/ RuntimeAnalysisWorkarounds.Options.ConstantFoldSamplingCodeStartId,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 1;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("ConstantFoldSamplingCodeStartId");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
