// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.graal.nodes;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.nodes.graphbuilderconf.JacocoIgnoreGenerated;

//        class: com.oracle.svm.core.graal.nodes.NewStoredContinuationNode
//       method: allocate(java.lang.Class<?>,java.lang.Class<?>,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_NewStoredContinuationNode_allocate extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        jdk.vm.ci.meta.ResolvedJavaType arg0;
        if (args[0].isConstant()) {
            jdk.vm.ci.meta.JavaConstant cst = args[0].asJavaConstant();
            arg0 = b.getConstantReflection()/* A CONSTANT_REFLECTION */.asJavaType(cst);
            if (arg0 == null) {
                arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(jdk.vm.ci.meta.ResolvedJavaType.class, cst);
            }
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_NewStoredContinuationNode_allocate.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        jdk.vm.ci.meta.ResolvedJavaType arg1;
        if (args[1].isConstant()) {
            jdk.vm.ci.meta.JavaConstant cst = args[1].asJavaConstant();
            arg1 = b.getConstantReflection()/* A CONSTANT_REFLECTION */.asJavaType(cst);
            if (arg1 == null) {
                arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(jdk.vm.ci.meta.ResolvedJavaType.class, cst);
            }
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_NewStoredContinuationNode_allocate.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[1];
            return false;
        }
        ValueNode arg2 = args[2];
        com.oracle.svm.core.graal.nodes.NewStoredContinuationNode node = new com.oracle.svm.core.graal.nodes.NewStoredContinuationNode(arg0, arg1, arg2);
        b.addPush(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_NewStoredContinuationNode_allocate(GeneratedPluginInjectionProvider injection) {
        super("allocate", java.lang.Class.class, java.lang.Class.class, int.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.graal.nodes.NewStoredContinuationNode
//       method: allocate(java.lang.Class<?>,java.lang.Class<?>,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_NewStoredContinuationNode_allocate implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_NewStoredContinuationNode_allocate();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        jdk.vm.ci.meta.ResolvedJavaType arg0;
        if (args.get(0).isConstant()) {
            jdk.vm.ci.meta.JavaConstant cst = args.get(0).asJavaConstant();
            arg0 = b.getConstantReflection()/* B CONSTANT_REFLECTION */.asJavaType(cst);
            if (arg0 == null) {
                arg0 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(jdk.vm.ci.meta.ResolvedJavaType.class, cst);
            }
        } else {
            return false;
        }
        jdk.vm.ci.meta.ResolvedJavaType arg1;
        if (args.get(1).isConstant()) {
            jdk.vm.ci.meta.JavaConstant cst = args.get(1).asJavaConstant();
            arg1 = b.getConstantReflection()/* B CONSTANT_REFLECTION */.asJavaType(cst);
            if (arg1 == null) {
                arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(jdk.vm.ci.meta.ResolvedJavaType.class, cst);
            }
        } else {
            return false;
        }
        ValueNode arg2 = args.get(2);
        com.oracle.svm.core.graal.nodes.NewStoredContinuationNode node = new com.oracle.svm.core.graal.nodes.NewStoredContinuationNode(arg0, arg1, arg2);
        b.addPush(JavaKind.Object, node);
        return true;
    }
}

public class PluginFactory_NewStoredContinuationNode implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.graal.nodes.NewStoredContinuationNode.class, new Plugin_NewStoredContinuationNode_allocate(injection));
    }
}
