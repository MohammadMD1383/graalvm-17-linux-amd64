// CheckStyle: stop header check
// CheckStyle: stop line length check
package com.oracle.svm.core.c;

// GENERATED CONTENT - DO NOT EDIT
// Annotated type: com.oracle.svm.core.c.CTypeConversionSupportImpl
// Annotation: com.oracle.svm.core.feature.AutomaticallyRegisteredImageSingleton
// Annotation processor: com.oracle.svm.processor.AutomaticallyRegisteredImageSingletonProcessor

import org.graalvm.nativeimage.ImageSingletons;
import com.oracle.svm.core.feature.AutomaticallyRegisteredFeature;
import com.oracle.svm.core.feature.InternalFeature;

@AutomaticallyRegisteredFeature
public final class CTypeConversionSupportImplFeature implements InternalFeature {
    @Override
    public void afterRegistration(AfterRegistrationAccess access) {
        var singleton = new com.oracle.svm.core.c.CTypeConversionSupportImpl();
        ImageSingletons.add(org.graalvm.nativeimage.impl.CTypeConversionSupport.class, singleton);
    }
}
