// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.graal.amd64;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.ConstantNode;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.nodes.graphbuilderconf.JacocoIgnoreGenerated;

//        class: com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters
//       method: offsetInFrameOrNull(jdk.vm.ci.code.Register)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_AMD64CalleeSavedRegisters_offsetInFrameOrNull extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_AMD64CalleeSavedRegisters_offsetInFrameOrNull.FUNCTION);
            return true;
        }
        jdk.vm.ci.code.Register arg0;
        if (args[0].isConstant()) {
            arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(jdk.vm.ci.code.Register.class, args[0].asJavaConstant());
            assert arg0 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_AMD64CalleeSavedRegisters_offsetInFrameOrNull.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        int result = com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters.offsetInFrameOrNull(arg0);
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_AMD64CalleeSavedRegisters_offsetInFrameOrNull(GeneratedPluginInjectionProvider injection) {
        super("offsetInFrameOrNull", jdk.vm.ci.code.Register.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters
//       method: offsetInFrameOrNull(jdk.vm.ci.code.Register)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_AMD64CalleeSavedRegisters_offsetInFrameOrNull implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_AMD64CalleeSavedRegisters_offsetInFrameOrNull();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        jdk.vm.ci.code.Register arg0;
        if (args.get(0).isConstant()) {
            arg0 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(jdk.vm.ci.code.Register.class, args.get(0).asJavaConstant());
            assert arg0 != null;
        } else {
            return false;
        }
        int result = com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters.offsetInFrameOrNull(arg0);
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters
//       method: singleton()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_AMD64CalleeSavedRegisters_singleton extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_AMD64CalleeSavedRegisters_singleton.FUNCTION);
            return true;
        }
        com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters result = com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters.singleton();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_AMD64CalleeSavedRegisters_singleton(GeneratedPluginInjectionProvider injection) {
        super("singleton");
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters
//       method: singleton()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_AMD64CalleeSavedRegisters_singleton implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_AMD64CalleeSavedRegisters_singleton();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters result = com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters.singleton();
        JavaConstant constant = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

public class PluginFactory_AMD64CalleeSavedRegisters implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters.class, new Plugin_AMD64CalleeSavedRegisters_offsetInFrameOrNull(injection));
        plugins.register(com.oracle.svm.core.graal.amd64.AMD64CalleeSavedRegisters.class, new Plugin_AMD64CalleeSavedRegisters_singleton(injection));
    }
}
