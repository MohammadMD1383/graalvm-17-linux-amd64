// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.cpufeature;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.debug.GraalError;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.nodes.graphbuilderconf.JacocoIgnoreGenerated;

//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_RuntimeCPUFeatureCheck_isSupported__0 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.api.replacements.SnippetReflectionProvider arg0 = snippetReflection;
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__0.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0, arg1)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__0.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_RuntimeCPUFeatureCheck_isSupported__0(GeneratedPluginInjectionProvider injection) {
        super("isSupported", java.lang.Enum.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__0 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__0();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.api.replacements.SnippetReflectionProvider arg0 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0, arg1)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>,java.lang.Enum<T>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_RuntimeCPUFeatureCheck_isSupported__1 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.api.replacements.SnippetReflectionProvider arg0 = snippetReflection;
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__1.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg2;
        if (args[1].isConstant()) {
            arg2 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[1].asJavaConstant());
            assert arg2 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__1.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[1];
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__1.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_RuntimeCPUFeatureCheck_isSupported__1(GeneratedPluginInjectionProvider injection) {
        super("isSupported", java.lang.Enum.class, java.lang.Enum.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>,java.lang.Enum<T>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__1 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__1();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.api.replacements.SnippetReflectionProvider arg0 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg2;
        if (args.get(1).isConstant()) {
            arg2 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(1).asJavaConstant());
            assert arg2 != null;
        } else {
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>,java.lang.Enum<T>,java.lang.Enum<T>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_RuntimeCPUFeatureCheck_isSupported__2 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.api.replacements.SnippetReflectionProvider arg0 = snippetReflection;
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg2;
        if (args[1].isConstant()) {
            arg2 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[1].asJavaConstant());
            assert arg2 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[1];
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg3;
        if (args[2].isConstant()) {
            arg3 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args[2].asJavaConstant());
            assert arg3 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[2];
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_RuntimeCPUFeatureCheck_isSupported__2(GeneratedPluginInjectionProvider injection) {
        super("isSupported", java.lang.Enum.class, java.lang.Enum.class, java.lang.Enum.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck
//       method: <T>isSupported(java.lang.Enum<T>,java.lang.Enum<T>,java.lang.Enum<T>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_RuntimeCPUFeatureCheck_isSupported__2();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.api.replacements.SnippetReflectionProvider arg0 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg2;
        if (args.get(1).isConstant()) {
            arg2 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(1).asJavaConstant());
            assert arg2 != null;
        } else {
            return false;
        }
        @SuppressWarnings({"rawtypes"})
        java.lang.Enum arg3;
        if (args.get(2).isConstant()) {
            arg3 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(java.lang.Enum.class, args.get(2).asJavaConstant());
            assert arg3 != null;
        } else {
            return false;
        }
        if (com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheckImpl.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        return false;
    }
}

public class PluginFactory_RuntimeCPUFeatureCheck implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck.class, new Plugin_RuntimeCPUFeatureCheck_isSupported__0(injection));
        plugins.register(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck.class, new Plugin_RuntimeCPUFeatureCheck_isSupported__1(injection));
        plugins.register(com.oracle.svm.core.cpufeature.RuntimeCPUFeatureCheck.class, new Plugin_RuntimeCPUFeatureCheck_isSupported__2(injection));
    }
}
