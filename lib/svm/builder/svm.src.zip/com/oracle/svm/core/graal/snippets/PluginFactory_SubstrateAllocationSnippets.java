// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.graal.snippets;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.debug.GraalError;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.ConstantNode;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.nodes.graphbuilderconf.JacocoIgnoreGenerated;

//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: afterArrayLengthOffset()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateAllocationSnippets_afterArrayLengthOffset extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_afterArrayLengthOffset.FUNCTION);
            return true;
        }
        int result = com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.afterArrayLengthOffset();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateAllocationSnippets_afterArrayLengthOffset() {
        super("afterArrayLengthOffset");
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: afterArrayLengthOffset()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateAllocationSnippets_afterArrayLengthOffset implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateAllocationSnippets_afterArrayLengthOffset();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        int result = com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.afterArrayLengthOffset();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: byteArrayIdentity()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateAllocationSnippets_byteArrayIdentity extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_byteArrayIdentity.FUNCTION);
            return true;
        }
        org.graalvm.word.LocationIdentity result = com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.byteArrayIdentity();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_SubstrateAllocationSnippets_byteArrayIdentity(GeneratedPluginInjectionProvider injection) {
        super("byteArrayIdentity");
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: byteArrayIdentity()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateAllocationSnippets_byteArrayIdentity implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateAllocationSnippets_byteArrayIdentity();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.word.LocationIdentity result = com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.byteArrayIdentity();
        JavaConstant constant = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callArrayHubErrorStub(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Class<?>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateAllocationSnippets_callArrayHubErrorStub extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callArrayHubErrorStub.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callArrayHubErrorStub.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateAllocationSnippets_callArrayHubErrorStub(GeneratedPluginInjectionProvider injection) {
        super("callArrayHubErrorStub", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, java.lang.Class.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(void.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callArrayHubErrorStub(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Class<?>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateAllocationSnippets_callArrayHubErrorStub implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateAllocationSnippets_callArrayHubErrorStub();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(void.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callInstanceHubErrorWithExceptionStub(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Class<?>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateAllocationSnippets_callInstanceHubErrorWithExceptionStub extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callInstanceHubErrorWithExceptionStub.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (com.oracle.svm.core.graal.nodes.ForeignCallWithExceptionNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callInstanceHubErrorWithExceptionStub.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateAllocationSnippets_callInstanceHubErrorWithExceptionStub(GeneratedPluginInjectionProvider injection) {
        super("callInstanceHubErrorWithExceptionStub", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, java.lang.Class.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(void.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callInstanceHubErrorWithExceptionStub(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Class<?>)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateAllocationSnippets_callInstanceHubErrorWithExceptionStub implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateAllocationSnippets_callInstanceHubErrorWithExceptionStub();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(void.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (com.oracle.svm.core.graal.nodes.ForeignCallWithExceptionNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callNewMultiArray(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.compiler.word.Word,int,org.graalvm.compiler.word.Word)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateAllocationSnippets_callNewMultiArray extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callNewMultiArray.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        ValueNode arg3 = args[2];
        ValueNode arg4 = args[3];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3, arg4)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callNewMultiArray.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateAllocationSnippets_callNewMultiArray(GeneratedPluginInjectionProvider injection) {
        super("callNewMultiArray", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, org.graalvm.compiler.word.Word.class, int.class, org.graalvm.compiler.word.Word.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(java.lang.Object.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callNewMultiArray(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.compiler.word.Word,int,org.graalvm.compiler.word.Word)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateAllocationSnippets_callNewMultiArray implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateAllocationSnippets_callNewMultiArray();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(java.lang.Object.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        ValueNode arg3 = args.get(2);
        ValueNode arg4 = args.get(3);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3, arg4)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callSlowNewArray(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.compiler.word.Word,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateAllocationSnippets_callSlowNewArray extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewArray.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        ValueNode arg3 = args[2];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewArray.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateAllocationSnippets_callSlowNewArray(GeneratedPluginInjectionProvider injection) {
        super("callSlowNewArray", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, org.graalvm.compiler.word.Word.class, int.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(java.lang.Object.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callSlowNewArray(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.compiler.word.Word,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewArray implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewArray();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(java.lang.Object.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        ValueNode arg3 = args.get(2);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callSlowNewInstance(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.compiler.word.Word)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateAllocationSnippets_callSlowNewInstance extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewInstance.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewInstance.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateAllocationSnippets_callSlowNewInstance(GeneratedPluginInjectionProvider injection) {
        super("callSlowNewInstance", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, org.graalvm.compiler.word.Word.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(java.lang.Object.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callSlowNewInstance(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.compiler.word.Word)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewInstance implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewInstance();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(java.lang.Object.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callSlowNewPodInstance(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.compiler.word.Word,int,byte[])
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateAllocationSnippets_callSlowNewPodInstance extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewPodInstance.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        ValueNode arg3 = args[2];
        ValueNode arg4 = args[3];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3, arg4)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewPodInstance.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateAllocationSnippets_callSlowNewPodInstance(GeneratedPluginInjectionProvider injection) {
        super("callSlowNewPodInstance", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, org.graalvm.compiler.word.Word.class, int.class, byte[].class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(java.lang.Object.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callSlowNewPodInstance(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.compiler.word.Word,int,byte[])
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewPodInstance implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewPodInstance();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(java.lang.Object.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        ValueNode arg3 = args.get(2);
        ValueNode arg4 = args.get(3);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3, arg4)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callSlowNewStoredContinuation(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.compiler.word.Word,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_SubstrateAllocationSnippets_callSlowNewStoredContinuation extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewStoredContinuation.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        ValueNode arg3 = args[2];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewStoredContinuation.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_SubstrateAllocationSnippets_callSlowNewStoredContinuation(GeneratedPluginInjectionProvider injection) {
        super("callSlowNewStoredContinuation", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, org.graalvm.compiler.word.Word.class, int.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(java.lang.Object.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: callSlowNewStoredContinuation(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.compiler.word.Word,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewStoredContinuation implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateAllocationSnippets_callSlowNewStoredContinuation();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(java.lang.Object.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        ValueNode arg3 = args.get(2);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: gcAllocationSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateAllocationSnippets_gcAllocationSupport extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_gcAllocationSupport.FUNCTION);
            return true;
        }
        com.oracle.svm.core.graal.snippets.GCAllocationSupport result = com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.gcAllocationSupport();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_SubstrateAllocationSnippets_gcAllocationSupport(GeneratedPluginInjectionProvider injection) {
        super("gcAllocationSupport");
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: gcAllocationSupport()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateAllocationSnippets_gcAllocationSupport implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateAllocationSnippets_gcAllocationSupport();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        com.oracle.svm.core.graal.snippets.GCAllocationSupport result = com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.gcAllocationSupport();
        JavaConstant constant = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: getMinimalBulkZeroingSize()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateAllocationSnippets_getMinimalBulkZeroingSize extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_getMinimalBulkZeroingSize.FUNCTION);
            return true;
        }
        com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets arg0;
        if (args[0].isConstant()) {
            arg0 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, args[0].asJavaConstant());
            assert arg0 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateAllocationSnippets_getMinimalBulkZeroingSize.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        int result = arg0.getMinimalBulkZeroingSize();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_SubstrateAllocationSnippets_getMinimalBulkZeroingSize(GeneratedPluginInjectionProvider injection) {
        super("getMinimalBulkZeroingSize", InvocationPlugin.Receiver.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets
//       method: getMinimalBulkZeroingSize()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateAllocationSnippets_getMinimalBulkZeroingSize implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateAllocationSnippets_getMinimalBulkZeroingSize();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets arg0;
        if (args.get(0).isConstant()) {
            arg0 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, args.get(0).asJavaConstant());
            assert arg0 != null;
        } else {
            return false;
        }
        int result = arg0.getMinimalBulkZeroingSize();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

public class PluginFactory_SubstrateAllocationSnippets implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, new Plugin_SubstrateAllocationSnippets_afterArrayLengthOffset());
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, new Plugin_SubstrateAllocationSnippets_byteArrayIdentity(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, new Plugin_SubstrateAllocationSnippets_callArrayHubErrorStub(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, new Plugin_SubstrateAllocationSnippets_callInstanceHubErrorWithExceptionStub(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, new Plugin_SubstrateAllocationSnippets_callNewMultiArray(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, new Plugin_SubstrateAllocationSnippets_callSlowNewArray(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, new Plugin_SubstrateAllocationSnippets_callSlowNewInstance(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, new Plugin_SubstrateAllocationSnippets_callSlowNewPodInstance(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, new Plugin_SubstrateAllocationSnippets_callSlowNewStoredContinuation(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, new Plugin_SubstrateAllocationSnippets_gcAllocationSupport(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.SubstrateAllocationSnippets.class, new Plugin_SubstrateAllocationSnippets_getMinimalBulkZeroingSize(injection));
    }
}
