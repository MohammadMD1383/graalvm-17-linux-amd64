// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.graal.snippets;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.debug.GraalError;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.ConstantNode;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.nodes.graphbuilderconf.JacocoIgnoreGenerated;

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: hasHeapBase()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_CEntryPointSnippets_hasHeapBase extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_hasHeapBase.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.graal.snippets.CEntryPointSnippets.hasHeapBase();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_CEntryPointSnippets_hasHeapBase() {
        super("hasHeapBase");
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: hasHeapBase()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_hasHeapBase implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_hasHeapBase();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.graal.snippets.CEntryPointSnippets.hasHeapBase();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeAssertionsEnabled()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_CEntryPointSnippets_runtimeAssertionsEnabled extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeAssertionsEnabled.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.graal.snippets.CEntryPointSnippets.runtimeAssertionsEnabled();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_CEntryPointSnippets_runtimeAssertionsEnabled() {
        super("runtimeAssertionsEnabled");
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeAssertionsEnabled()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_runtimeAssertionsEnabled implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_runtimeAssertionsEnabled();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.graal.snippets.CEntryPointSnippets.runtimeAssertionsEnabled();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,com.oracle.svm.core.c.function.CEntryPointCreateIsolateParameters,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_CEntryPointSnippets_runtimeCall__0 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCall__0.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        ValueNode arg3 = args[2];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCall__0.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_CEntryPointSnippets_runtimeCall__0(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, com.oracle.svm.core.c.function.CEntryPointCreateIsolateParameters.class, int.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(int.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,com.oracle.svm.core.c.function.CEntryPointCreateIsolateParameters,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_runtimeCall__0 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_runtimeCall__0();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(int.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        ValueNode arg3 = args.get(2);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.nativeimage.Isolate,boolean,boolean,int,boolean)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_CEntryPointSnippets_runtimeCall__1 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCall__1.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        ValueNode arg3 = args[2];
        ValueNode arg4 = args[3];
        ValueNode arg5 = args[4];
        ValueNode arg6 = args[5];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3, arg4, arg5, arg6)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCall__1.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_CEntryPointSnippets_runtimeCall__1(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, org.graalvm.nativeimage.Isolate.class, boolean.class, boolean.class, int.class, boolean.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(int.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.nativeimage.Isolate,boolean,boolean,int,boolean)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_runtimeCall__1 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_runtimeCall__1();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(int.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        ValueNode arg3 = args.get(2);
        ValueNode arg4 = args.get(3);
        ValueNode arg5 = args.get(4);
        ValueNode arg6 = args.get(5);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3, arg4, arg5, arg6)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.nativeimage.Isolate)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_CEntryPointSnippets_runtimeCall__2 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCall__2.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCall__2.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_CEntryPointSnippets_runtimeCall__2(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, org.graalvm.nativeimage.Isolate.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(int.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.nativeimage.Isolate)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_runtimeCall__2 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_runtimeCall__2();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(int.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.nativeimage.IsolateThread)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_CEntryPointSnippets_runtimeCall__3 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCall__3.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCall__3.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_CEntryPointSnippets_runtimeCall__3(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, org.graalvm.nativeimage.IsolateThread.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(int.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.nativeimage.IsolateThread)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_runtimeCall__3 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_runtimeCall__3();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(int.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Throwable)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_CEntryPointSnippets_runtimeCall__4 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCall__4.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCall__4.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_CEntryPointSnippets_runtimeCall__4(GeneratedPluginInjectionProvider injection) {
        super("runtimeCall", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, java.lang.Throwable.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(int.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCall(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,java.lang.Throwable)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_runtimeCall__4 implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_runtimeCall__4();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(int.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCallEnsureJavaThread(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_CEntryPointSnippets_runtimeCallEnsureJavaThread extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCallEnsureJavaThread.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCallEnsureJavaThread.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_CEntryPointSnippets_runtimeCallEnsureJavaThread(GeneratedPluginInjectionProvider injection) {
        super("runtimeCallEnsureJavaThread", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(void.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCallEnsureJavaThread(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_runtimeCallEnsureJavaThread implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_runtimeCallEnsureJavaThread();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(void.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCallFailFatally(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,int,org.graalvm.nativeimage.c.type.CCharPointer)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_CEntryPointSnippets_runtimeCallFailFatally extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCallFailFatally.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        ValueNode arg3 = args[2];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCallFailFatally.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_CEntryPointSnippets_runtimeCallFailFatally(GeneratedPluginInjectionProvider injection) {
        super("runtimeCallFailFatally", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, int.class, org.graalvm.nativeimage.c.type.CCharPointer.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(void.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCallFailFatally(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,int,org.graalvm.nativeimage.c.type.CCharPointer)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_runtimeCallFailFatally implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_runtimeCallFailFatally();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(void.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        ValueNode arg3 = args.get(2);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2, arg3)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCallInitializeIsolate(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,com.oracle.svm.core.c.function.CEntryPointCreateIsolateParameters)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_CEntryPointSnippets_runtimeCallInitializeIsolate extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCallInitializeIsolate.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCallInitializeIsolate.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_CEntryPointSnippets_runtimeCallInitializeIsolate(GeneratedPluginInjectionProvider injection) {
        super("runtimeCallInitializeIsolate", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, com.oracle.svm.core.c.function.CEntryPointCreateIsolateParameters.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(int.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCallInitializeIsolate(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,com.oracle.svm.core.c.function.CEntryPointCreateIsolateParameters)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_runtimeCallInitializeIsolate implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_runtimeCallInitializeIsolate();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(int.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCallIsAttached(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.nativeimage.Isolate)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_CEntryPointSnippets_runtimeCallIsAttached extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCallIsAttached.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        ValueNode arg2 = args[1];
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCallIsAttached.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_CEntryPointSnippets_runtimeCallIsAttached(GeneratedPluginInjectionProvider injection) {
        super("runtimeCallIsAttached", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, org.graalvm.nativeimage.Isolate.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(boolean.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCallIsAttached(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor,org.graalvm.nativeimage.Isolate)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_runtimeCallIsAttached implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_runtimeCallIsAttached();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(boolean.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        ValueNode arg2 = args.get(1);
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1, arg2)) {
            return true;
        }
        return false;
    }
}

//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCallTearDownIsolate(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
final class Plugin_CEntryPointSnippets_runtimeCallTearDownIsolate extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        org.graalvm.compiler.core.common.type.Stamp arg0 = stamp;
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args[0].isConstant()) {
            arg1 = snippetReflection/* A SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args[0].asJavaConstant());
            assert arg1 != null;
        } else {
            if (b.shouldDeferPlugin(this)) {
                b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCallTearDownIsolate.FUNCTION);
                return true;
            }
            assert b.canDeferPlugin(this) : b.getClass().toString() + " " + args[0];
            return false;
        }
        assert verifyForeignCallDescriptor(b, targetMethod, arg1) : arg1;
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1)) {
            return true;
        }
        if (b.canDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_CEntryPointSnippets_runtimeCallTearDownIsolate.FUNCTION);
            return true;
        }
        throw GraalError.shouldNotReachHere("Can't inline plugin " + b.getClass().toString());
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;
    private final org.graalvm.compiler.core.common.type.Stamp stamp;

    Plugin_CEntryPointSnippets_runtimeCallTearDownIsolate(GeneratedPluginInjectionProvider injection) {
        super("runtimeCallTearDownIsolate", org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class);
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
        this.stamp = injection.getInjectedStamp(int.class, false);
    }
}
//        class: com.oracle.svm.core.graal.snippets.CEntryPointSnippets
//       method: runtimeCallTearDownIsolate(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$CustomFactoryPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_CEntryPointSnippets_runtimeCallTearDownIsolate implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_CEntryPointSnippets_runtimeCallTearDownIsolate();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        org.graalvm.compiler.core.common.type.Stamp arg0 = injection.getInjectedStamp(int.class, false);
        org.graalvm.compiler.core.common.spi.ForeignCallDescriptor arg1;
        if (args.get(0).isConstant()) {
            arg1 = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.asObject(org.graalvm.compiler.core.common.spi.ForeignCallDescriptor.class, args.get(0).asJavaConstant());
            assert arg1 != null;
        } else {
            return false;
        }
        if (org.graalvm.compiler.nodes.extended.ForeignCallNode.intrinsify(b, arg0, arg1)) {
            return true;
        }
        return false;
    }
}

public class PluginFactory_CEntryPointSnippets implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_hasHeapBase());
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_runtimeAssertionsEnabled());
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_runtimeCall__0(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_runtimeCall__1(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_runtimeCall__2(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_runtimeCall__3(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_runtimeCall__4(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_runtimeCallEnsureJavaThread(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_runtimeCallFailFatally(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_runtimeCallInitializeIsolate(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_runtimeCallIsAttached(injection));
        plugins.register(com.oracle.svm.core.graal.snippets.CEntryPointSnippets.class, new Plugin_CEntryPointSnippets_runtimeCallTearDownIsolate(injection));
    }
}
