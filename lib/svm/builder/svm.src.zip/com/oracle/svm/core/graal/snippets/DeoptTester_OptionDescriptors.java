// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: DeoptTester.java
package com.oracle.svm.core.graal.snippets;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class DeoptTester_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "DeoptimizeAll": {
            return OptionDescriptor.create(
                /*name*/ "DeoptimizeAll",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Compiles all methods as deoptimization targets for testing",
                /*declaringClass*/ DeoptTester.Options.class,
                /*fieldName*/ "DeoptimizeAll",
                /*option*/ DeoptTester.Options.DeoptimizeAll,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 1;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("DeoptimizeAll");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
