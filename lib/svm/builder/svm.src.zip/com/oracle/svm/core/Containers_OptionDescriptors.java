// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// Source: Containers.java
package com.oracle.svm.core;

import java.util.*;
import org.graalvm.compiler.options.*;
import org.graalvm.compiler.options.OptionType;

public class Containers_OptionDescriptors implements OptionDescriptors {
    @Override
    public OptionDescriptor get(String value) {
        switch (value) {
        // CheckStyle: stop line length check
        case "PreferContainerQuotaForCPUCount": {
            return OptionDescriptor.create(
                /*name*/ "PreferContainerQuotaForCPUCount",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Calculate the container CPU availability based on the value of quotas (if set), when true. Otherwise, use the CPU shares value, provided it is less than quota.",
                /*declaringClass*/ Containers.Options.class,
                /*fieldName*/ "PreferContainerQuotaForCPUCount",
                /*option*/ Containers.Options.PreferContainerQuotaForCPUCount,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        case "UseContainerSupport": {
            return OptionDescriptor.create(
                /*name*/ "UseContainerSupport",
                /*optionType*/ OptionType.Debug,
                /*optionValueType*/ Boolean.class,
                /*help*/ "Enable detection and runtime container configuration support.",
                /*declaringClass*/ Containers.Options.class,
                /*fieldName*/ "UseContainerSupport",
                /*option*/ Containers.Options.UseContainerSupport,
                /*deprecated*/ false,
                /*deprecationMessage*/ "");
        }
        // CheckStyle: resume line length check
        }
        return null;
    }

    @Override
    public Iterator<OptionDescriptor> iterator() {
        return new Iterator<>() {
            int i = 0;
            @Override
            public boolean hasNext() {
                return i < 2;
            }
            @Override
            public OptionDescriptor next() {
                switch (i++) {
                    case 0: return get("PreferContainerQuotaForCPUCount");
                    case 1: return get("UseContainerSupport");
                }
                throw new NoSuchElementException();
            }
        };
    }
}
