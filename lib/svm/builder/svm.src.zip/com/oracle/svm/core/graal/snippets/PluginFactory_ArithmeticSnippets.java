// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core.graal.snippets;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedNodeIntrinsicInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;

//        class: com.oracle.svm.core.graal.snippets.ArithmeticSnippets
//       method: safeDiv(int,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_ArithmeticSnippets_safeDiv__0 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        com.oracle.svm.core.graal.snippets.SafeSignedDivNode node = new com.oracle.svm.core.graal.snippets.SafeSignedDivNode(arg0, arg1);
        b.addPush(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_ArithmeticSnippets_safeDiv__0() {
        super("safeDiv", int.class, int.class);
    }
}

//        class: com.oracle.svm.core.graal.snippets.ArithmeticSnippets
//       method: safeDiv(long,long)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_ArithmeticSnippets_safeDiv__1 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        com.oracle.svm.core.graal.snippets.SafeSignedDivNode node = new com.oracle.svm.core.graal.snippets.SafeSignedDivNode(arg0, arg1);
        b.addPush(JavaKind.Long, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_ArithmeticSnippets_safeDiv__1() {
        super("safeDiv", long.class, long.class);
    }
}

//        class: com.oracle.svm.core.graal.snippets.ArithmeticSnippets
//       method: safeRem(int,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_ArithmeticSnippets_safeRem__2 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        com.oracle.svm.core.graal.snippets.SafeSignedRemNode node = new com.oracle.svm.core.graal.snippets.SafeSignedRemNode(arg0, arg1);
        b.addPush(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_ArithmeticSnippets_safeRem__2() {
        super("safeRem", int.class, int.class);
    }
}

//        class: com.oracle.svm.core.graal.snippets.ArithmeticSnippets
//       method: safeRem(long,long)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_ArithmeticSnippets_safeRem__3 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        com.oracle.svm.core.graal.snippets.SafeSignedRemNode node = new com.oracle.svm.core.graal.snippets.SafeSignedRemNode(arg0, arg1);
        b.addPush(JavaKind.Long, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_ArithmeticSnippets_safeRem__3() {
        super("safeRem", long.class, long.class);
    }
}

//        class: com.oracle.svm.core.graal.snippets.ArithmeticSnippets
//       method: safeUDiv(int,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_ArithmeticSnippets_safeUDiv__4 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        com.oracle.svm.core.graal.snippets.SafeUnsignedDivNode node = new com.oracle.svm.core.graal.snippets.SafeUnsignedDivNode(arg0, arg1);
        b.addPush(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_ArithmeticSnippets_safeUDiv__4() {
        super("safeUDiv", int.class, int.class);
    }
}

//        class: com.oracle.svm.core.graal.snippets.ArithmeticSnippets
//       method: safeUDiv(long,long)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_ArithmeticSnippets_safeUDiv__5 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        com.oracle.svm.core.graal.snippets.SafeUnsignedDivNode node = new com.oracle.svm.core.graal.snippets.SafeUnsignedDivNode(arg0, arg1);
        b.addPush(JavaKind.Long, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_ArithmeticSnippets_safeUDiv__5() {
        super("safeUDiv", long.class, long.class);
    }
}

//        class: com.oracle.svm.core.graal.snippets.ArithmeticSnippets
//       method: safeURem(int,int)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_ArithmeticSnippets_safeURem__6 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        com.oracle.svm.core.graal.snippets.SafeUnsignedRemNode node = new com.oracle.svm.core.graal.snippets.SafeUnsignedRemNode(arg0, arg1);
        b.addPush(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_ArithmeticSnippets_safeURem__6() {
        super("safeURem", int.class, int.class);
    }
}

//        class: com.oracle.svm.core.graal.snippets.ArithmeticSnippets
//       method: safeURem(long,long)
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedNodeIntrinsicPlugin$ConstructorPlugin
final class Plugin_ArithmeticSnippets_safeURem__7 extends GeneratedNodeIntrinsicInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        ValueNode arg0 = args[0];
        ValueNode arg1 = args[1];
        com.oracle.svm.core.graal.snippets.SafeUnsignedRemNode node = new com.oracle.svm.core.graal.snippets.SafeUnsignedRemNode(arg0, arg1);
        b.addPush(JavaKind.Long, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.graph.Node.NodeIntrinsic.class;
    }

    Plugin_ArithmeticSnippets_safeURem__7() {
        super("safeURem", long.class, long.class);
    }
}

public class PluginFactory_ArithmeticSnippets implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.graal.snippets.ArithmeticSnippets.class, new Plugin_ArithmeticSnippets_safeDiv__0());
        plugins.register(com.oracle.svm.core.graal.snippets.ArithmeticSnippets.class, new Plugin_ArithmeticSnippets_safeDiv__1());
        plugins.register(com.oracle.svm.core.graal.snippets.ArithmeticSnippets.class, new Plugin_ArithmeticSnippets_safeRem__2());
        plugins.register(com.oracle.svm.core.graal.snippets.ArithmeticSnippets.class, new Plugin_ArithmeticSnippets_safeRem__3());
        plugins.register(com.oracle.svm.core.graal.snippets.ArithmeticSnippets.class, new Plugin_ArithmeticSnippets_safeUDiv__4());
        plugins.register(com.oracle.svm.core.graal.snippets.ArithmeticSnippets.class, new Plugin_ArithmeticSnippets_safeUDiv__5());
        plugins.register(com.oracle.svm.core.graal.snippets.ArithmeticSnippets.class, new Plugin_ArithmeticSnippets_safeURem__6());
        plugins.register(com.oracle.svm.core.graal.snippets.ArithmeticSnippets.class, new Plugin_ArithmeticSnippets_safeURem__7());
    }
}
