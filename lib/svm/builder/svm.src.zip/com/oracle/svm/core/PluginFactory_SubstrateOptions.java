// CheckStyle: stop header check
// CheckStyle: stop line length check
// GENERATED CONTENT - DO NOT EDIT
// GENERATORS: org.graalvm.compiler.replacements.processor.ReplacementsAnnotationProcessor, org.graalvm.compiler.replacements.processor.PluginGenerator
package com.oracle.svm.core;


import java.lang.annotation.Annotation;
import jdk.vm.ci.meta.JavaConstant;
import jdk.vm.ci.meta.JavaKind;
import jdk.vm.ci.meta.ResolvedJavaMethod;
import org.graalvm.compiler.core.common.type.Stamp;
import org.graalvm.compiler.graph.NodeInputList;
import org.graalvm.compiler.nodes.ConstantNode;
import org.graalvm.compiler.nodes.PluginReplacementNode;
import org.graalvm.compiler.nodes.ValueNode;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedFoldInvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginFactory;
import org.graalvm.compiler.nodes.graphbuilderconf.GeneratedPluginInjectionProvider;
import org.graalvm.compiler.nodes.graphbuilderconf.GraphBuilderContext;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugin;
import org.graalvm.compiler.nodes.graphbuilderconf.InvocationPlugins;
import org.graalvm.compiler.nodes.graphbuilderconf.JacocoIgnoreGenerated;

//        class: com.oracle.svm.core.SubstrateOptions
//       method: codeAlignment()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_codeAlignment extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_codeAlignment.FUNCTION);
            return true;
        }
        int result = com.oracle.svm.core.SubstrateOptions.codeAlignment();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_codeAlignment() {
        super("codeAlignment");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: codeAlignment()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_codeAlignment implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_codeAlignment();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        int result = com.oracle.svm.core.SubstrateOptions.codeAlignment();
        JavaConstant constant = JavaConstant.forInt(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: getSourceLevelDebug()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_getSourceLevelDebug extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_getSourceLevelDebug.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.getSourceLevelDebug();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_getSourceLevelDebug() {
        super("getSourceLevelDebug");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: getSourceLevelDebug()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_getSourceLevelDebug implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_getSourceLevelDebug();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.getSourceLevelDebug();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: getSourceLevelDebugFilter()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_getSourceLevelDebugFilter extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_getSourceLevelDebugFilter.FUNCTION);
            return true;
        }
        @SuppressWarnings({"rawtypes"})
        java.util.function.Predicate result = com.oracle.svm.core.SubstrateOptions.getSourceLevelDebugFilter();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_SubstrateOptions_getSourceLevelDebugFilter(GeneratedPluginInjectionProvider injection) {
        super("getSourceLevelDebugFilter");
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: getSourceLevelDebugFilter()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_getSourceLevelDebugFilter implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_getSourceLevelDebugFilter();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        @SuppressWarnings({"rawtypes"})
        java.util.function.Predicate result = com.oracle.svm.core.SubstrateOptions.getSourceLevelDebugFilter();
        JavaConstant constant = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: optimizationLevel()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_optimizationLevel extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_optimizationLevel.FUNCTION);
            return true;
        }
        com.oracle.svm.core.SubstrateOptions.OptimizationLevel result = com.oracle.svm.core.SubstrateOptions.optimizationLevel();
        JavaConstant constant = snippetReflection/* A SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    private final org.graalvm.compiler.api.replacements.SnippetReflectionProvider snippetReflection;

    Plugin_SubstrateOptions_optimizationLevel(GeneratedPluginInjectionProvider injection) {
        super("optimizationLevel");
        this.snippetReflection = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class);
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: optimizationLevel()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_optimizationLevel implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_optimizationLevel();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        com.oracle.svm.core.SubstrateOptions.OptimizationLevel result = com.oracle.svm.core.SubstrateOptions.optimizationLevel();
        JavaConstant constant = injection.getInjectedArgument(org.graalvm.compiler.api.replacements.SnippetReflectionProvider.class)/* B SNIPPET_REFLECTION */.forObject(result);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Object, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: supportCompileInIsolates()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_supportCompileInIsolates extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_supportCompileInIsolates.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.supportCompileInIsolates();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_supportCompileInIsolates() {
        super("supportCompileInIsolates");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: supportCompileInIsolates()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_supportCompileInIsolates implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_supportCompileInIsolates();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.supportCompileInIsolates();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useEconomyCompilerConfig()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useEconomyCompilerConfig extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useEconomyCompilerConfig.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useEconomyCompilerConfig();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useEconomyCompilerConfig() {
        super("useEconomyCompilerConfig");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useEconomyCompilerConfig()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useEconomyCompilerConfig implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useEconomyCompilerConfig();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useEconomyCompilerConfig();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useLLVMBackend()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useLLVMBackend extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useLLVMBackend.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useLLVMBackend();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useLLVMBackend() {
        super("useLLVMBackend");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useLLVMBackend()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useLLVMBackend implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useLLVMBackend();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useLLVMBackend();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

//        class: com.oracle.svm.core.SubstrateOptions
//       method: useRememberedSet()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
final class Plugin_SubstrateOptions_useRememberedSet extends GeneratedFoldInvocationPlugin {

    @Override
    public boolean execute(GraphBuilderContext b, ResolvedJavaMethod targetMethod, InvocationPlugin.Receiver receiver, ValueNode[] args) {
        if (!b.isPluginEnabled(this)) {
            return false;
        }
        if (b.shouldDeferPlugin(this)) {
            b.replacePlugin(this, targetMethod, args, PluginReplacementNode_SubstrateOptions_useRememberedSet.FUNCTION);
            return true;
        }
        boolean result = com.oracle.svm.core.SubstrateOptions.useRememberedSet();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* A META_ACCESS */, b.getGraph()/* A STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
    @Override
    public Class<? extends Annotation> getSource() {
        return org.graalvm.compiler.api.replacements.Fold.class;
    }

    Plugin_SubstrateOptions_useRememberedSet() {
        super("useRememberedSet");
    }
}
//        class: com.oracle.svm.core.SubstrateOptions
//       method: useRememberedSet()
// generated-by: org.graalvm.compiler.replacements.processor.GeneratedFoldPlugin
@JacocoIgnoreGenerated("deferred plugin support that is only called in libgraal")
final class PluginReplacementNode_SubstrateOptions_useRememberedSet implements PluginReplacementNode.ReplacementFunction {
    static PluginReplacementNode.ReplacementFunction FUNCTION = new PluginReplacementNode_SubstrateOptions_useRememberedSet();

    @Override
    public boolean replace(GraphBuilderContext b, GeneratedPluginInjectionProvider injection, Stamp stamp, NodeInputList<ValueNode> args) {
        boolean result = com.oracle.svm.core.SubstrateOptions.useRememberedSet();
        JavaConstant constant = JavaConstant.forInt(result ? 1 : 0);
        ConstantNode node = ConstantNode.forConstant(constant, b.getMetaAccess()/* B META_ACCESS */, b.getGraph()/* B STRUCTURED_GRAPH */);
        b.push(JavaKind.Int, node);
        return true;
    }
}

public class PluginFactory_SubstrateOptions implements GeneratedPluginFactory {
    @Override
    public void registerPlugins(InvocationPlugins plugins, GeneratedPluginInjectionProvider injection) {
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_codeAlignment());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_getSourceLevelDebug());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_getSourceLevelDebugFilter(injection));
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_optimizationLevel(injection));
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_supportCompileInIsolates());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useEconomyCompilerConfig());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useLLVMBackend());
        plugins.register(com.oracle.svm.core.SubstrateOptions.class, new Plugin_SubstrateOptions_useRememberedSet());
    }
}
